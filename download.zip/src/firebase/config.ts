export const firebaseConfig = {
  "projectId": "studio-3903841175-fbde6",
  "appId": "1:192493596653:web:d9b4e28c2410a8606901e4",
  "apiKey": "AIzaSyAkwh6Fjq1Nd0gni457Oap2dFi4x3NYhIA",
  "authDomain": "studio-3903841175-fbde6.firebaseapp.com",
  "measurementId": "",
  "messagingSenderId": "192493596653"
};
