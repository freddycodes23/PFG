
'use client';

import { Button } from '@/components/ui/button';
import Link from 'next/link';
import Image from 'next/image';

export default function Home() {
  return (
    <div className="flex flex-col min-h-screen">
      <main className="flex-1 flex flex-col items-center justify-center text-center p-4">
        <div className="space-y-8">
           <Image
              src="/pyramid-nameplate.png"
              alt="Pyramid Group Funerals"
              width={400}
              height={100}
              className="mx-auto object-contain"
              priority
            />

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link href="/login" className="w-full sm:w-auto">
              <Button className="w-full" size="lg">Log In</Button>
            </Link>
             <span className="text-muted-foreground">or</span>
            <Link href="/signup" className="w-full sm:w-auto">
              <Button className="w-full" variant="outline" size="lg">Create Account</Button>
            </Link>
          </div>
        </div>
      </main>
      <footer className="flex flex-col gap-2 sm:flex-row py-6 w-full shrink-0 items-center px-4 md:px-6 border-t">
        <p className="text-xs text-muted-foreground">&copy; 2025 Pyramid Group Funerals. All rights reserved.</p>
        <nav className="sm:ml-auto flex gap-4 sm:gap-6">
          <Link className="text-xs hover:underline underline-offset-4" href="#">
             Terms of Service
          </Link>
           <Link className="text-xs hover:underline underline-offset-4" href="#">
             Privacy Policy
          </Link>
        </nav>
      </footer>
    </div>
  );
}
