
'use client';

import Link from "next/link"
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button"
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import Image from "next/image"
import { useToast } from "@/hooks/use-toast";

export default function SignupPage() {
    const router = useRouter();
    const { toast } = useToast();


    const handleSignup = (e: React.FormEvent) => {
        e.preventDefault();
        toast({
            title: "Account Created",
            description: "Your account has been successfully created. Please log in.",
        });
        router.push("/login");
    }

  return (
    <div className="flex items-center justify-center min-h-screen bg-background relative">
      <Card className="mx-auto max-w-sm w-full z-10">
        <CardHeader className="space-y-4">
          <Link href="/" className="flex justify-center">
             <Image
                src="/pyramid-nameplate.png"
                alt="Pyramid Group Funerals"
                width={200}
                height={50}
                className="object-contain"
              />
          </Link>
          <CardTitle className="text-2xl text-center">Create an Account</CardTitle>
          <CardDescription className="text-center">
            Enter your information to create an account
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form className="grid gap-4" onSubmit={handleSignup}>
            <div className="grid gap-2">
              <Label htmlFor="full-name">Full Name</Label>
              <Input id="full-name" placeholder="John Doe" required />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="email">Email (Optional)</Label>
              <Input
                id="email"
                type="email"
                placeholder="m@example.com"
              />
            </div>
            <div className="grid gap-2">
                <Label htmlFor="phone">Phone Number</Label>
                <div className="flex items-center">
                  <span className="inline-flex items-center px-3 rounded-l-md border border-r-0 border-input bg-background text-sm text-muted-foreground">
                    +27
                  </span>
                  <Input
                    id="phone"
                    type="tel"
                    placeholder="72 123 4567"
                    required
                    className="rounded-l-none"
                  />
                </div>
              </div>
            <div className="grid gap-2">
              <Label htmlFor="password">Password</Label>              <Input id="password" type="password" required />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="confirm-password">Confirm Password</Label>
              <Input id="confirm-password" type="password" required />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="otp">OTP</Label>
              <Input id="otp" type="text" placeholder="Enter OTP" required />
            </div>
            <Button type="submit" className="w-full">Create Account</Button>
          </form>
          <div className="mt-4 text-center text-sm">
            Already have an account?{" "}
            <Link href="/login" className="underline">
              Login
            </Link>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
