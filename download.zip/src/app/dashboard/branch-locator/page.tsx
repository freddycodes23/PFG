'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Loader2, MapPin, LocateFixed, AlertTriangle, ExternalLink, Building } from 'lucide-react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { findBranchAction } from '@/app/actions';
import type { LocateNearbyBranchOutput } from '@/ai/flows/locate-nearby-branch';
import { branches, type Branch } from '@/lib/branches';

export default function BranchLocatorPage() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [selectedBranch, setSelectedBranch] = useState<Branch | LocateNearbyBranchOutput | null>(null);

  const handleLocate = () => {
    if (!navigator.geolocation) {
      setError('Geolocation is not supported by your browser.');
      return;
    }

    setLoading(true);
    setError(null);
    setSelectedBranch(null);

    navigator.geolocation.getCurrentPosition(
      async (position) => {
        const { latitude, longitude } = position.coords;
        try {
          const result = await findBranchAction({ latitude, longitude });
          setSelectedBranch({
            name: result.branchName,
            address: result.branchAddress
          });
        } catch (e: any) {
          setError(e.message || 'An unexpected error occurred.');
        } finally {
          setLoading(false);
        }
      },
      (err) => {
        setError(`Unable to retrieve your location: ${err.message}`);
        setLoading(false);
      }
    );
  };
  
  const handleBranchSelect = (branchName: string) => {
    const branch = branches.find(b => b.name === branchName);
    if (branch) {
      setSelectedBranch(branch);
    }
  }

  const getBranchName = (branch: Branch | LocateNearbyBranchOutput | null): string => {
    if (!branch) return '';
    if ('branchName' in branch) {
      return branch.branchName;
    }
    return branch.name;
  }

  const getBranchAddress = (branch: Branch | LocateNearbyBranchOutput | null): string => {
    if (!branch) return '';
     if ('branchAddress' in branch) {
      return branch.branchAddress;
    }
    return branch.address;
  }

  return (
    <div className="flex-1 space-y-4 p-4 md:p-8 pt-6">
      <div className="flex items-center justify-between space-y-2">
        <h2 className="text-3xl font-bold tracking-tight font-headline">
          Branch Locator
        </h2>
      </div>
      <p className="text-muted-foreground">
        Find a Pyramid Group Funerals branch near you.
      </p>

      <div className="grid gap-8 md:grid-cols-2">
          <Card className="max-w-lg">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Building className="h-6 w-6 text-primary" />
                Select a Branch
              </CardTitle>
              <CardDescription>
                Choose a branch from the list to see its details.
              </CardDescription>
            </CardHeader>
            <CardContent>
                <Select onValueChange={handleBranchSelect}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select a branch" />
                  </SelectTrigger>
                  <SelectContent>
                    {branches.map(branch => (
                      <SelectItem key={branch.name} value={branch.name}>{branch.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
            </CardContent>
          </Card>

        <Card className="max-w-lg">
            <CardHeader>
            <CardTitle className="flex items-center gap-2">
                <LocateFixed className="h-6 w-6 text-primary" />
                Find a Nearby Branch
            </CardTitle>
            <CardDescription>
                Use your device's location to find the closest branch to you.
            </CardDescription>
            </CardHeader>
            <CardContent>
                {error && (
                    <Alert variant="destructive">
                    <AlertTriangle className="h-4 w-4" />
                    <AlertTitle>Error</AlertTitle>
                    <AlertDescription>{error}</AlertDescription>
                    </Alert>
                )}
            </CardContent>
            <CardFooter>
            <Button onClick={handleLocate} disabled={loading} className="w-full">
                {loading ? (
                <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Searching...
                </>
                ) : (
                'Use My Current Location'
                )}
            </Button>
            </CardFooter>
        </Card>
      </div>

       {selectedBranch && (
            <Card className="max-w-lg mt-8">
              <CardHeader>
                <CardTitle className="text-lg font-headline">{getBranchName(selectedBranch)}</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-start gap-3">
                  <MapPin className="h-5 w-5 mt-1 text-muted-foreground" />
                  <p>{getBranchAddress(selectedBranch)}</p>
                </div>
              </CardContent>
              <CardFooter>
                  <a
                    href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(getBranchAddress(selectedBranch))}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full"
                  >
                    <Button variant="outline" className="w-full">
                      <ExternalLink className="mr-2 h-4 w-4" />
                      Get Directions
                    </Button>
                  </a>
              </CardFooter>
            </Card>
          )}
    </div>
  );
}
