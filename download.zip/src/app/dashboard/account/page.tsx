
'use client';

import { useState } from 'react';
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { PlaceHolderImages } from "@/lib/placeholder-images";
import { Trash2, UserPlus, Send, Loader2, Upload } from "lucide-react";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Separator } from '@/components/ui/separator';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { generateReferralMessageAction } from '@/app/actions';

type Dependant = {
  id: number;
  name: string;
  relationship: string;
};

const initialDependants: Dependant[] = [
  { id: 1, name: "Jane Doe", relationship: "Spouse" },
  { id: 2, name: "John Doe Jr.", relationship: "Child" },
];

export default function AccountPage() {
  const { toast } = useToast();
  const avatarImage = PlaceHolderImages.find((p) => p.id === "account-avatar");

  const [dependants, setDependants] = useState<Dependant[]>(initialDependants);
  const [newDependantName, setNewDependantName] = useState("");
  const [newDependantRelationship, setNewDependantRelationship] = useState("");
  const [newDependantIdNumber, setNewDependantIdNumber] = useState("");
  const [newDependantDob, setNewDependantDob] = useState("");
  
  const [hasGroceryBenefit, setHasGroceryBenefit] = useState(false);
  const [funeralPlan, setFuneralPlan] = useState("Khomakhwatsi: Lite Package");

  const [referralName, setReferralName] = useState('');
  const [referralPhone, setReferralPhone] = useState('');
  const [referralRelationship, setReferralRelationship] = useState<'Friend' | 'Relative'>('Friend');
  const [isSendingReferral, setIsSendingReferral] = useState(false);

  const handleRemoveDependant = (id: number) => {
    setDependants(dependants.filter((d) => d.id !== id));
    toast({
      title: "Dependant Removed",
      description: "The dependant has been successfully removed from your policy.",
    });
  };

  const handleAddDependant = (e: React.FormEvent) => {
    e.preventDefault();
    if (newDependantName && newDependantRelationship && newDependantIdNumber && newDependantDob) {
      const newDependant = {
        id: Date.now(),
        name: newDependantName,
        relationship: newDependantRelationship,
      };
      setDependants([...dependants, newDependant]);
      setNewDependantName("");
      setNewDependantRelationship("");
      setNewDependantIdNumber("");
      setNewDependantDob("");
      toast({
        title: "Dependant Added",
        description: `${newDependant.name} has been successfully added to your policy.`,
      });
    }
  };

  const toggleGroceryBenefit = (checked: boolean) => {
    setHasGroceryBenefit(checked);
    toast({
      title: `Grocery Benefit ${checked ? 'Added' : 'Removed'}`,
      description: `The Grocery Benefit has been successfully ${checked ? 'added to' : 'removed from'} your policy.`,
    });
  }
  
  const handlePlanChange = (value: string) => {
    setFuneralPlan(value);
    toast({
        title: "Plan Changed",
        description: `Your funeral plan has been updated to ${value}.`,
    });
  }

  const handleProfileSave = () => {
    toast({
        title: "Profile Updated",
        description: "Your profile information has been successfully saved.",
    });
  }
  
  const handleIdUpload = (dependantName: string) => {
    toast({
      title: "Document Uploaded",
      description: `Certified ID for ${dependantName} has been uploaded.`,
    })
  }

  const handleReferralSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!referralName || !referralPhone || !referralRelationship) {
        toast({
            title: "Missing Information",
            description: "Please fill out all fields for the referral.",
            variant: "destructive",
        });
        return;
    }

    setIsSendingReferral(true);
    try {
        const pwaLink = window.location.origin;
        const result = await generateReferralMessageAction({
            referrerName: "User Name", // Replace with actual user name from auth state
            recipientName: referralName,
            relationship: referralRelationship,
            pwaLink: pwaLink,
        });

        toast({
            title: "Referral Sent!",
            description: `Message sent to ${referralName}: "${result.message}"`,
        });

        setReferralName('');
        setReferralPhone('');
        setReferralRelationship('Friend');

    } catch (error: any) {
        toast({
            title: "Failed to Send Referral",
            description: error.message || "An unexpected error occurred.",
            variant: "destructive",
        });
    } finally {
        setIsSendingReferral(false);
    }
  };


  return (
    <div className="flex-1 space-y-8 p-4 md:p-8 pt-6">
      <div className="space-y-2">
        <h2 className="text-3xl font-bold tracking-tight font-headline">
          My Account
        </h2>
        <p className="text-muted-foreground">
          Manage your account, policy, and dependants.
        </p>
      </div>

      {/* Profile Details Card */}
      <Card>
        <CardHeader>
          <CardTitle>Profile Details</CardTitle>
          <CardDescription>
            Update your personal information here. Click save when you're done.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex items-center gap-4">
            <Avatar className="h-20 w-20">
              {avatarImage && <AvatarImage src={avatarImage.imageUrl} data-ai-hint={avatarImage.imageHint} />}
              <AvatarFallback>U</AvatarFallback>
            </Avatar>
            <Button variant="outline">Change Photo</Button>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="name">Full Name</Label>
              <Input id="name" defaultValue="User Name" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="email">Email (Optional)</Label>
              <Input id="email" type="email" defaultValue="user@email.com" />
            </div>
          </div>
          <div className="space-y-2">
              <Label htmlFor="phone">Phone Number</Label>
              <div className="flex items-center">
                  <span className="inline-flex items-center px-3 rounded-l-md border border-r-0 border-input bg-background text-sm text-muted-foreground">
                    +27
                  </span>
                  <Input
                    id="phone"
                    type="tel"
                    placeholder="72 123 4567"
                    defaultValue="721234567"
                    className="rounded-l-none"
                  />
                </div>
            </div>
           <div className="space-y-2">
              <Label htmlFor="current-password">Current Password</Label>
              <Input id="current-password" type="password" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="new-password">New Password</Label>
              <Input id="new-password" type="password" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="confirm-new-password">Confirm New Password</Label>
              <Input id="confirm-new-password" type="password" />
            </div>
        </CardContent>
        <CardFooter>
          <Button onClick={handleProfileSave}>Save Profile Changes</Button>
        </CardFooter>
      </Card>

      {/* Refer a Friend Card */}
      <Card>
        <CardHeader>
          <CardTitle>Refer a Friend or Relative</CardTitle>
          <CardDescription>
            Share the benefits of Pyramid Group Funerals with someone you know.
          </CardDescription>
        </CardHeader>
        <form onSubmit={handleReferralSubmit}>
            <CardContent className="space-y-6">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-2">
                        <Label htmlFor="referral-name">Recipient's Name</Label>
                        <Input 
                            id="referral-name" 
                            placeholder="e.g. Jane Doe"
                            value={referralName}
                            onChange={(e) => setReferralName(e.target.value)}
                            required
                        />
                    </div>
                    <div className="space-y-2">
                        <Label htmlFor="referral-phone">Recipient's Phone Number</Label>
                         <div className="flex items-center">
                            <span className="inline-flex items-center px-3 rounded-l-md border border-r-0 border-input bg-background text-sm text-muted-foreground">
                                +27
                            </span>
                            <Input
                                id="referral-phone"
                                type="tel"
                                placeholder="82 987 6543"
                                value={referralPhone}
                                onChange={(e) => setReferralPhone(e.target.value)}
                                required
                                className="rounded-l-none"
                            />
                        </div>
                    </div>
                </div>
                <div className="space-y-3">
                    <Label>Relationship to You</Label>
                    <RadioGroup 
                        value={referralRelationship} 
                        onValueChange={(value: 'Friend' | 'Relative') => setReferralRelationship(value)} 
                        className="flex gap-4"
                    >
                        <div className="flex items-center space-x-2">
                            <RadioGroupItem value="Friend" id="friend" />
                            <Label htmlFor="friend">Friend</Label>
                        </div>
                        <div className="flex items-center space-x-2">
                            <RadioGroupItem value="Relative" id="relative" />
                            <Label htmlFor="relative">Relative</Label>
                        </div>
                    </RadioGroup>
                </div>
            </CardContent>
            <CardFooter>
                <Button type="submit" disabled={isSendingReferral}>
                    {isSendingReferral ? (
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    ) : (
                        <Send className="mr-2 h-4 w-4" />
                    )}
                    Send Referral
                </Button>
            </CardFooter>
        </form>
      </Card>

      {/* Policy Management Card */}
      <Card>
        <CardHeader>
          <CardTitle>Policy Management</CardTitle>
          <CardDescription>
            Manage your funeral cover and additional benefits.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="funeral-plan">Funeral Plan</Label>
              <Select value={funeralPlan} onValueChange={handlePlanChange}>
                <SelectTrigger id="funeral-plan">
                  <SelectValue placeholder="Select a plan" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Khomakhwatsi: Main Package">Khomakhwatsi: Main Package</SelectItem>
                  <SelectItem value="Khomakhwatsi: Lite Package">Khomakhwatsi: Lite Package</SelectItem>
                </SelectContent>
              </Select>
            </div>
             <Separator />
            <div className="flex items-center justify-between rounded-lg border p-4">
              <div className="space-y-0.5">
                <Label htmlFor="grocery-benefit" className="text-base">Grocery Benefit</Label>
                <p className="text-sm text-muted-foreground">
                  Add the monthly grocery benefit to your policy.
                </p>
              </div>
              <Switch
                id="grocery-benefit"
                checked={hasGroceryBenefit}
                onCheckedChange={toggleGroceryBenefit}
              />
            </div>
        </CardContent>
      </Card>
      
      {/* Dependant Management Card */}
      <Card>
        <CardHeader>
          <CardTitle>Dependant Management</CardTitle>
          <CardDescription>
            Add or remove dependants and upload their certified documents.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div>
            <h3 className="text-md font-medium mb-4">Current Dependants</h3>
            <div className="space-y-4">
              {dependants.map((dependant) => (
                <div key={dependant.id} className="flex items-center justify-between rounded-lg border p-4">
                  <div>
                    <p className="font-medium">{dependant.name}</p>
                    <p className="text-sm text-muted-foreground">{dependant.relationship}</p>
                  </div>
                  <div className="flex items-center gap-2">
                     <Button variant="outline" size="sm" onClick={() => handleIdUpload(dependant.name)}>
                        <Upload className="h-4 w-4 mr-2"/>
                        Upload ID
                     </Button>
                    <Button variant="ghost" size="icon" onClick={() => handleRemoveDependant(dependant.id)}>
                      <Trash2 className="h-5 w-5 text-destructive" />
                      <span className="sr-only">Remove Dependant</span>
                    </Button>
                  </div>
                </div>
              ))}
              {dependants.length === 0 && (
                <p className="text-sm text-muted-foreground text-center py-4">You have no dependants on your policy.</p>
              )}
            </div>
          </div>
          <Separator />
           <div>
             <h3 className="text-md font-medium mb-4">Add New Dependant</h3>
              <form onSubmit={handleAddDependant} className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="new-dependant-name">Full Name</Label>
                        <Input 
                            id="new-dependant-name" 
                            placeholder="e.g. Mary Smith"
                            value={newDependantName}
                            onChange={(e) => setNewDependantName(e.target.value)}
                            required
                        />
                      </div>
                      <div className="space-y-2">
                          <Label htmlFor="new-dependant-relationship">Relationship</Label>
                          <Input 
                            id="new-dependant-relationship" 
                            placeholder="e.g. Daughter"
                            value={newDependantRelationship}
                            onChange={(e) => setNewDependantRelationship(e.target.value)}
                            required
                          />
                      </div>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="new-dependant-id">ID Number</Label>
                      <Input 
                          id="new-dependant-id" 
                          placeholder="e.g. 9001015000080"
                          value={newDependantIdNumber}
                          onChange={(e) => setNewDependantIdNumber(e.target.value)}
                          required
                      />
                    </div>
                    <div className="space-y-2">
                        <Label htmlFor="new-dependant-dob">Date of Birth</Label>
                        <Input 
                          id="new-dependant-dob" 
                          type="date"
                          value={newDependantDob}
                          onChange={(e) => setNewDependantDob(e.target.value)}
                          required
                        />
                    </div>
                  </div>
                  <div className="space-y-2">
                     <Label htmlFor="dependant-id-upload">Upload Certified ID</Label>
                     <Input id="dependant-id-upload" type="file" />
                  </div>
                  <Button type="submit" className="w-full sm:w-auto">
                    <UserPlus className="mr-2 h-4 w-4" />
                    Add Dependant
                  </Button>
              </form>
           </div>
        </CardContent>
      </Card>
    </div>
  );
}
