import Image from 'next/image';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { PlaceHolderImages } from '@/lib/placeholder-images';
import { Phone, Mail, Users } from 'lucide-react';

export default function GriefSupportPage() {
  const supportImage = PlaceHolderImages.find((p) => p.id === 'grief-support-main');

  return (
    <div className="flex-1 space-y-6 p-4 md:p-8 pt-6">
      <div className="space-y-2">
        <h2 className="text-3xl font-bold tracking-tight font-headline">Grief Support</h2>
        <p className="text-muted-foreground">
          Navigating loss is a difficult journey. We are here to support you.
        </p>
      </div>

      <Card className="overflow-hidden">
        <div className="grid md:grid-cols-2">
          {supportImage && (
            <div className="relative min-h-[250px] md:min-h-full">
              <Image
                src={supportImage.imageUrl}
                alt={supportImage.description}
                fill
                className="object-cover"
                data-ai-hint={supportImage.imageHint}
              />
            </div>
          )}
          <div className="p-6 md:p-8">
            <h3 className="font-headline text-2xl font-semibold mb-4">Our Commitment to Your Well-being</h3>
            <p className="text-muted-foreground mb-4">
              The loss of a loved one can be one of the most challenging experiences in life. At Pyramid Group Funerals, our care extends beyond the funeral service. We offer aftercare programmes and resources to help you and your family cope with grief and begin the healing process.
            </p>
            <p className="text-muted-foreground">
              You are not alone. Our bereavement support is designed to provide a safe space for you to express your feelings and connect with others who understand what you are going through.
            </p>
          </div>
        </div>
      </Card>

      <div className="grid gap-6 md:grid-cols-3">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-3">
              <Phone className="h-6 w-6 text-primary" />
              24/7 Support Line
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground">
              Our dedicated support line is available any time of day or night.
            </p>
            <p className="text-lg font-semibold mt-2">(123) 456-7890</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-3">
              <Users className="h-6 w-6 text-primary" />
              Support Groups
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground">
              Join one of our professionally-led support groups to share your experience in a confidential setting.
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-3">
              <Mail className="h-6 w-6 text-primary" />
              Email Counseling
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground">
              If you prefer to write, our counselors are available to provide support via email. Contact us at <a href="mailto:support@pyramid.com" className="text-primary hover:underline">support@pyramid.com</a>.
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
