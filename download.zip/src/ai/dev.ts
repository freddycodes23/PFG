import { config } from 'dotenv';
config();

import '@/ai/flows/locate-nearby-branch.ts';
import '@/ai/flows/generate-referral-message.ts';
