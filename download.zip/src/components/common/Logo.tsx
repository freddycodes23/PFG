import type { SVGProps } from 'react';

export function Logo(props: SVGProps<SVGSVGElement>) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 40 40"
      width="40"
      height="40"
      {...props}
      className={`fill-current ${props.className || ''}`}
    >
      <g>
        <path d="M20,35 L5,20 L20,5 L35,20 L20,35 Z M20,10 L10,20 L20,30 L30,20 L20,10 Z" className="text-primary" />
      </g>
    </svg>
  );
}
