export type Branch = {
  name: string;
  address: string;
};

export const branches: Branch[] = [
  {
    name: "Maboloka Branch",
    address: "Office no 07, Maboloka Thathe Main Office",
  },
  {
    name: "Swartruggens Branch",
    address: "Shop number 10, 33/219 Boshoff Street, Indian Complex, Swartruggens 2835",
  },
  {
    name: "Moruleng Branch",
    address: "Stand no 30001 Green site Moruleng Front opposite Moruleng Mall.",
  },
  {
    name: "Brits Branch",
    address: "72 Pienaar Street, Next to Surgery (General Practitioner)",
  },
  {
    name: "Sunrise Branch",
    address: "Molapo Drive House, Number 10081 (Ext10) Front opposite Joy and Peace Pre school",
  },
  {
    name: "Letlhabile Branch",
    address: "Office No 20 Letlhabile Complex, Next to Top Tiles",
  },
  {
    name: "Modikwe Branch",
    address: "Stand No 0464, Oustard Section, Modikwe. Next to Modikwe General Dealer (Junior Shop)",
  },
  {
    name: "Lethabong Branch",
    address: "2863 Thabo Mokhaba Str (Old Building Material), Kwa Rooi. Next to McCafe",
  },
  {
    name: "Lekgalong Branch",
    address: "Shop No 1, Front Opposite Maphosse Car Wash & Chesanyama Fourway Stop (Next to Taxi Rank)",
  },
  {
    name: "Ledig Branch",
    address: "567 Bakubung Road, Maboe Business Center Next to Madiba car wash, opposite Ledig Small industries",
  },
  {
    name: "Koster Branch",
    address: "9 Jameson Rd, Opposite Nite Owl B&B Next to Chiibuku store.",
  },
  {
    name: "Sandfontein Branch",
    address: "944B Sekgatleng Sec, Sandfontein, Opposite Usave",
  },
  {
    name: "Luka Branch",
    address: "Stand no B297 Mogono, Opposite Matimalenyora Bottle store & Usafe",
  },
  {
    name: "Monakato Branch",
    address: "Stand no.1268 ext1, Monakato, Next to Monakato community Hall and Monakato hardware",
  },
  {
    name: "Rustenburg Branch",
    address: "4 Von Wielligh Street Rustenburg Next to Family Friend",
  },
  {
    name: "Mahikeng Branch",
    address: "Shop Number 1 Main Street Opposite Lewis furniture on your way to Absa Bank",
  },
  {
    name: "Tlhabane Branch",
    address: "Office no 32, Foro Mall Spar Complex Next to ABSA ATM Monareng Street",
  },
];
